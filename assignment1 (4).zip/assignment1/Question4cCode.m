% code that supports written solution to question 4c
T = 5;
H = [1,4,5;4,2,6;5,6,3];
[u1,v1] = question4c(Ut1,T,H,normU1);
[u2,v2] = question4c(Ut2,T,H,normU2);
[u3,v3] = question4c(Ut3,T,H,normU3);
[u4,v4] = question4c(Ut4,T,H,normU4);
[u1,u2,u3,u4];
[v1,v2,v3,v4];
