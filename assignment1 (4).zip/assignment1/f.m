function output = f(t,H)
output = 1i*H*t; 
end